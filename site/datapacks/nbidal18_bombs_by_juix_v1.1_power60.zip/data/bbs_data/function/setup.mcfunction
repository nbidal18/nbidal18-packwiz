scoreboard objectives add show_recipes trigger
scoreboard objectives add show_recipes_weblinks trigger
scoreboard objectives add juix_recipes_tellraw_id dummy

#
#	DEFAULT
#

gamerule sendCommandFeedback false
gamerule commandBlockOutput false

scoreboard objectives add bbs_itemCount dummy
setblock 0 -64 0 minecraft:barrel

scoreboard objectives add bbs_item_clicked minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bbs_bomb_timer dummy
scoreboard objectives add bbs_duration_timer dummy
scoreboard objectives add bbs_duration_cooldown dummy
scoreboard objectives add bbs_effect_duration dummy

scoreboard objectives add bbs_motion_x1 dummy
scoreboard objectives add bbs_motion_y1 dummy
scoreboard objectives add bbs_motion_z1 dummy
scoreboard objectives add bbs_motion_x2 dummy
scoreboard objectives add bbs_motion_y2 dummy
scoreboard objectives add bbs_motion_z2 dummy

scoreboard players set world bombs_installation_test 1
tellraw @a {"text":"Bombs Installed","color":"green"}