#   /trigger show_recipes

scoreboard players enable @a show_recipes
execute as @a[scores={juix_recipes_tellraw_id=7}] run function bbs_data:recipes/stop
execute as @a[scores={show_recipes=1..}] run function bbs_data:recipes/show

scoreboard players enable @a show_recipes_weblinks
execute as @a[scores={show_recipes_weblinks=1..}] run function bbs_data:recipes/show_links

#   MAIN

execute as @a[scores={bbs_item_clicked=1..}] run function bbs_data:item_clicked

#   DYNAMITE
# One tagged scan replaces seven separate whole-world @e scans per tick.
execute as @e[tag=bbs_runtime] at @s run function bbs_data:items/runtime_dispatch
