execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_model_data=120] run function bbs_data:items/dynamite_launch

scoreboard players reset @s bbs_item_clicked