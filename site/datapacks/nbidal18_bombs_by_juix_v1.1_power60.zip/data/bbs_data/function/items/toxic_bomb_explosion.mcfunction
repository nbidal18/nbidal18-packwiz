summon tnt ~ ~ ~

summon armor_stand ~ ~ ~ {Tags:[bbs_runtime,bbs_bomb_effects,bbs_toxic_bomb_effects],Marker:1b,Invisible:1b,NoBasePlate:1b,Invulnerable:1b,NoGravity:1b,PersistenceRequired:1b,DisabledSlots:4144959}

# --- Sol et végétation de base ---
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:coarse_dirt replace dirt
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:mycelium replace grass_block
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:soul_sand replace sand
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:soul_soil replace gravel
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:mud replace farmland

# --- Eau et glace ---
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:muddy_mangrove_roots replace ice
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:muddy_mangrove_roots replace packed_ice
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:muddy_mangrove_roots replace blue_ice

# --- Feuillage et végétaux ---
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dead_bush replace short_grass
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dead_bush replace tall_grass
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dead_brain_coral_block replace cherry_leaves
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dead_brain_coral_block replace oak_leaves
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dead_tube_coral_block replace birch_leaves
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dead_fire_coral_block replace acacia_leaves
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dead_fire_coral_block replace jungle_leaves
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dead_bubble_coral_block replace spruce_leaves
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dead_bubble_coral_block replace mangrove_leaves

# --- Fleurs et plantes mortes ---
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:air replace poppy
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:air replace dandelion
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:air replace allium
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:air replace azure_bluet
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:air replace cornflower
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:air replace oxeye_daisy
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:air replace lilac
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:air replace rose_bush
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:air replace peony
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:air replace sunflower

# --- Arbres et troncs ---
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dark_oak_log replace oak_log
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dark_oak_log replace birch_log
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dark_oak_log replace spruce_log
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dark_oak_log replace jungle_log
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dark_oak_log replace acacia_log
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dark_oak_log replace mangrove_log
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:dark_oak_log replace cherry_log

# --- Autres effets visuels / ambiance ---
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:basalt replace stone
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:blackstone replace cobblestone
