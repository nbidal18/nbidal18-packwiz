scoreboard players remove @s bbs_duration_cooldown 1
playsound minecraft:block.note_block.cow_bell neutral @a ~ ~ ~ 1 1

execute if entity @s[scores={bbs_duration_cooldown=10}] run data merge entity @s {CustomName:'[{"text":"00:10","color":"red"}]'}
execute if entity @s[scores={bbs_duration_cooldown=9}] run data merge entity @s {CustomName:'[{"text":"00:09","color":"red"}]'}
execute if entity @s[scores={bbs_duration_cooldown=8}] run data merge entity @s {CustomName:'[{"text":"00:08","color":"red"}]'}
execute if entity @s[scores={bbs_duration_cooldown=7}] run data merge entity @s {CustomName:'[{"text":"00:07","color":"red"}]'}
execute if entity @s[scores={bbs_duration_cooldown=6}] run data merge entity @s {CustomName:'[{"text":"00:06","color":"red"}]'}
execute if entity @s[scores={bbs_duration_cooldown=5}] run data merge entity @s {CustomName:'[{"text":"00:05","color":"red"}]'}
execute if entity @s[scores={bbs_duration_cooldown=4}] run data merge entity @s {CustomName:'[{"text":"00:04","color":"red"}]'}
execute if entity @s[scores={bbs_duration_cooldown=3}] run data merge entity @s {CustomName:'[{"text":"00:03","color":"red"}]'}
execute if entity @s[scores={bbs_duration_cooldown=2}] run data merge entity @s {CustomName:'[{"text":"00:02","color":"red"}]'}
execute if entity @s[scores={bbs_duration_cooldown=1}] run data merge entity @s {CustomName:'[{"text":"00:01","color":"red"}]'}

execute if entity @s[scores={bbs_duration_cooldown=4}] run playsound minecraft:entity.tnt.primed neutral @a ~ ~ ~ 1 1

execute if entity @s[scores={bbs_duration_cooldown=0},tag=bbs_bomb1] run summon fireball ~ ~1 ~ {ExplosionPower:3,Motion:[0.0,-1.0,0.0]}
execute if entity @s[scores={bbs_duration_cooldown=0},tag=bbs_bomb2] run function bbs_data:items/dangerous_bomb_explosion
execute if entity @s[scores={bbs_duration_cooldown=0},tag=bbs_bomb3] run function bbs_data:items/atomic_bomb_explosion
execute if entity @s[scores={bbs_duration_cooldown=0},tag=bbs_bomb4] run function bbs_data:items/toxic_bomb_explosion

execute if entity @s[scores={bbs_duration_cooldown=0}] run setblock ~ ~ ~ glass replace
execute if entity @s[scores={bbs_duration_cooldown=0}] run kill @e[tag=bbs_bomb_texture,distance=..3,limit=1,sort=nearest]
execute if entity @s[scores={bbs_duration_cooldown=0}] run kill @s

scoreboard players reset @s bbs_duration_timer