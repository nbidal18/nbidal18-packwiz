scoreboard players add @s bbs_duration_timer 1

execute if entity @s[scores={bbs_duration_timer=20..}] run function bbs_data:items/bomb_update_cooldown