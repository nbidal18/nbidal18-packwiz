summon fireball ~ ~1 ~ {ExplosionPower:7,Motion:[0.0,-1.0,0.0]}
summon tnt ~ ~ ~