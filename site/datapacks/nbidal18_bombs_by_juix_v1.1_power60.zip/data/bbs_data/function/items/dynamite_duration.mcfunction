scoreboard players add @s bbs_duration_timer 1
execute if entity @s[scores={bbs_duration_timer=80..}] run function bbs_data:items/dynamite_explosion