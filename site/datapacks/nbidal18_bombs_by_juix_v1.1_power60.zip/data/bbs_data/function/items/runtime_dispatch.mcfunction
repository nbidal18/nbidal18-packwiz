# DYNAMITE
execute if entity @s[tag=bbs_dynamite] if block ~ ~-0.1 ~ air run function bbs_data:items/dynamite_duration
execute if entity @s[tag=bbs_dynamite] unless block ~ ~-0.1 ~ air run function bbs_data:items/dynamite_explosion

# LIT TNT
execute if entity @s[tag=bbs_lit_tnt] run function bbs_data:items/lit_tnt

# BOMBS
execute if entity @s[tag=bbs_bomb,tag=!bbs_update] run function bbs_data:items/bomb_set_cooldown
execute if entity @s[tag=bbs_bomb] run function bbs_data:items/bomb

# LINGERING BOMB EFFECTS
scoreboard players add @s[tag=bbs_bomb_effects] bbs_effect_duration 1
execute if entity @s[tag=bbs_bomb_effects] run function bbs_data:items/bomb_effects
