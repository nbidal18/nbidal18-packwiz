# Compatibility for bomb items crafted before nbidal18 4.0.0. New items receive
# bbs_runtime at creation; these low-frequency scans only adopt legacy entities.
tag @e[tag=bbs_dynamite,tag=!bbs_runtime] add bbs_runtime
tag @e[tag=bbs_lit_tnt,tag=!bbs_runtime] add bbs_runtime
tag @e[tag=bbs_bomb,tag=!bbs_runtime] add bbs_runtime
tag @e[tag=bbs_bomb_effects,tag=!bbs_runtime] add bbs_runtime
schedule function bbs_data:legacy_runtime_migration 20t replace
