
scoreboard objectives remove bbs_item_clicked
scoreboard objectives remove bbs_itemCount

scoreboard objectives remove bbs_bomb_timer
scoreboard objectives remove bbs_duration_timer
scoreboard objectives remove bbs_duration_cooldown
scoreboard objectives remove bbs_effect_duration

scoreboard objectives remove bbs_motion_x1
scoreboard objectives remove bbs_motion_y1
scoreboard objectives remove bbs_motion_z1
scoreboard objectives remove bbs_motion_x2
scoreboard objectives remove bbs_motion_y2
scoreboard objectives remove bbs_motion_z2

scoreboard objectives remove bombs_installation_test

tellraw @a {"text":"Uninstalled Bombs","color":"red"}
datapack disable "file/nbidal18_bombs_by_juix_v1.1_power60"
datapack disable "file/nbidal18_bombs_by_juix_v1.1_power60.zip"
